# Co:DEX MVP

This is the full MVP for Co:DEX.

## Setup

- Run `npm install`
- Start backend with `node app.js`
- Host frontend as static or use Vercel/Render.
